const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const User = require('./models/Users');
const sequelize = require('./db');

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.post('/register', async (req, res) => {
  const { username, email, password } = req.body;
  try {
    const newUser = await User.create({ username, email, password });
    res.json(newUser);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});


sequelize.sync().then(() => {
  app.listen(3000, () => {
    console.log('Server is running on port 3000');
  });
}).catch(error => console.log(error));
