document.querySelector('.botao').addEventListener('click', async () => {
    const username = document.getElementById('floatingInputGroup1').value;
    const email = document.getElementById('floatingInput').value;
    const password = document.getElementById('floatingPassword').value;
  
    const response = await fetch('http://localhost:3000/register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ username, email, password })
    });
  
    if (response.ok) {
      alert('Usuário cadastrado com sucesso!');
    } else {
      const error = await response.json();
      alert('Erro ao cadastrar usuário: ' + error.error);
    }
  });
  